var app = angular.module("MainApp", []);

app.controller("OrderController", function($scope, Order, WebSocket){
	$scope.orders = [];
	$scope.statusList = ["New","Approved","Rejected","Closed"];

	$scope.onWebMessage = function(event) {
		var message = event.data;
		if (message) {
			var order = angular.fromJson(message);
			if (angular.isArray(order)) { 
				$scope.orders = order; 
			} else {
				$scope.insertOrUpdate(order); 
			}
		}
		$scope.$apply();
	}

	$scope.insertOrUpdate = function(order) {
		var index = -1;
		for (var idx = 0; idx < $scope.orders.length; idx++) {
			if ($scope.orders[idx].id === order.id) {
				index = idx;
				break;
			}
		}
		if (index == -1) {
			$scope.orders.push(order)
		} else {
			$scope.orders[index] = order;
		}
	}

	$scope.filterDeleteItem = function(value, index, items) {
		return (value.status !== "Deleted");
	}

	$scope.onCreateClick = function() {
		var order = Order.create();
		var message = angular.toJson(order, false);
		WebSocket.send("ManageOrders", message);
	}

	$scope.onEditClick = function(order) {
		order.original = angular.copy(order);
		order.editing = true;
	}

	$scope.onSaveClick = function(order) {
		delete(order.original);
		delete(order.editing);
		var message = angular.toJson(order, false);
		WebSocket.send("ManageOrders", message);
	}

	$scope.onDeleteClick = function(order) {
		if (order.editing) {
			order.editing = false;
			if (order.original) {
				var message = angular.toJson(order.original, false);
				WebSocket.send("ManageOrders", message);
			}
			return;
		}
		order.status = "Deleted";
		var message = angular.toJson(order, false);
		WebSocket.send("ManageOrders", message);
	}

	$scope.onConnectClick = function() {
		WebSocket.connect("ManageOrders", $scope.onWebMessage);
	}

	//Connecting to WebSocket
	WebSocket.connect("ManageOrders", $scope.onWebMessage);
});

app.service("Order", function(){
	this.create = function() {
		return {
			id: null,
			dt: new Date().getTime(),
			status: "New",
			qty: (Math.random()*100).toFixed(0),
			price: (Math.random()*500).toFixed(0)
		};
	}
});

app.service("WebSocket", function($location){
	this.webSockets = {};
	this.connect = function(endPoint, onMessage) {
		var webSocket = this.webSockets[endPoint];

		// Ensures only one connection is open at a time
        if(webSocket !== undefined && webSocket.readyState !== WebSocket.CLOSED){
            console.log("WebSocket is already opened.");
            return;
        }
        
        // Create a new instance of the websocket
        webSocket = new WebSocket("ws://" + $location.host() + ":" + $location.port() + "/WebSockets/" + endPoint);
        this.webSockets[endPoint] = webSocket;

        webSocket.onopen = function(event){
            // For reasons I can't determine, onopen gets called twice
            // and the first time event.data is undefined.
            // Leave a comment if you know the answer.
            if(event.data === undefined) 
                return;

            console.log(event.data);
        };
        
        webSocket.onmessage = onMessage;

        webSocket.onclose = function(event){
            console.log("Connection closed");
        };
	};

	this.send = function(endPoint, txtMessage) {
		var webSocket = this.webSockets[endPoint];
		if(webSocket === undefined || webSocket.readyState === WebSocket.CLOSED){
            console.log("WebSocket is already closed! Reconnect before sending message");
            return;
        }
		webSocket.send(txtMessage);
	};

	this.close = function(endPoint) {
		var webSocket = this.webSockets[endPoint];
		if(webSocket !== undefined || webSocket.readyState !== WebSocket.CLOSED){
			webSocket.close();
        }
	}
});