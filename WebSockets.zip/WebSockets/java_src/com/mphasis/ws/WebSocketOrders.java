package com.mphasis.ws;

import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import javax.websocket.OnClose;
import javax.websocket.OnMessage;
import javax.websocket.OnOpen;
import javax.websocket.Session;
import javax.websocket.server.ServerEndpoint;

import com.mphasis.model.Order;
import com.mphasis.ws.coders.OrderDecoder;
import com.mphasis.ws.coders.OrderEncoder;
import com.mphasis.ws.coders.OrdersEncoder;

@ServerEndpoint(
	value = "/ManageOrders", 
	decoders = { OrderDecoder.class },
	encoders = { OrderEncoder.class, OrdersEncoder.class }
)
public class WebSocketOrders {

	private static final Set<Session> allSessions = Collections.synchronizedSet(new HashSet<Session>());
	private static final Map<Integer, Order> allOrders = new HashMap<Integer, Order>();

	@OnOpen
	public void onSessionOpen(Session session) throws Exception {
		System.out.println(session.getId() + " has opened connection");
		allSessions.add(session);
		Collection<Order> orders = allOrders.values();
		session.getBasicRemote().sendObject(orders);
	}

	@OnMessage
	public void onSessionMessage(Order order, Session session) throws Exception {
		System.out.println(session.getId() + " has sent a message");
		if (order.getId() == null) {
			int id = new Integer(allOrders.size() + 1);
			order.setId(id);
		}
		allOrders.put(order.getId(), order);
		for (Session sess : allSessions) {
			sess.getBasicRemote().sendObject(order);
		}
	}

	@OnClose
	public void onSessionClose(Session session) {
		System.out.println(session.getId() + " has closed connection");
		allSessions.remove(session);
	}

}
