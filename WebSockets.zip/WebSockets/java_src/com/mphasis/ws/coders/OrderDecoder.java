package com.mphasis.ws.coders;

import java.io.IOException;

import javax.websocket.DecodeException;
import javax.websocket.Decoder;
import javax.websocket.EndpointConfig;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.mphasis.model.Order;

public class OrderDecoder implements Decoder.Text<Order> {

	private static ObjectMapper mapper = new ObjectMapper();

	@Override
	public void destroy() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void init(EndpointConfig arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public Order decode(String msg) throws DecodeException {
		Order order = null;
		try {
			order = mapper.readValue(msg, Order.class);
		} catch (IOException e) {
			e.printStackTrace();
		}
		return order;
	}

	@Override
	public boolean willDecode(String msg) {
		return (msg != null);
	}

}
